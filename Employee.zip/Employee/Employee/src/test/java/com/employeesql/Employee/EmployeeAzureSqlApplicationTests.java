package com.employeesql.Employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAzureSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
